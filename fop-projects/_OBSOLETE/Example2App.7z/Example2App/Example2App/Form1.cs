﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Example2App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // the XSL FO file
            File xsltfile = new File(@"C:\dev\jDev\fop\Example2App\Example2App\HelloWorld.xsl");
            // the XML file from which we take the name
            StreamSource source = new StreamSource(new File(@"C:\dev\jDev\fop\Example2App\Example2App\Hello.xml"));
            // creation of transform source
            StreamSource transformSource = new StreamSource(xsltfile);
            // create an instance of fop factory
            FopFactory fopFactory = FopFactory.newInstance();
            // a user agent is needed for transformation
            FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
            // to store output
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();

            Transformer xslfoTransformer;
            try
            {
                xslfoTransformer = getTransformer(transformSource);
                // Construct fop with desired output format
                Fop fop;
                try
                {
                    fop = fopFactory.newFop
                        (MimeConstants.MIME_PDF, foUserAgent, outStream);
                    // Resulting SAX events (the generated FO) 
                    // must be piped through to FOP
                    Result res = new SAXResult(fop.getDefaultHandler());

                    // Start XSLT transformation and FOP processing
                    try
                    {
                        // everything will happen here..
                        xslfoTransformer.transform(source, res);
                        // if you want to get the PDF bytes, use the following code
                        //return outStream.toByteArray();

                        // if you want to save PDF file use the following code
                        /*File pdffile = new File("Result.pdf");
                        OutputStream out = new java.io.FileOutputStream(pdffile);
                                    out = new java.io.BufferedOutputStream(out);
                                    FileOutputStream str = new FileOutputStream(pdffile);
                                    str.write(outStream.toByteArray());
                                    str.close();
                                    out.close();*/

                        // to write the content to out put stream
                        byte[] pdfBytes = outStream.toByteArray();
                        response.setContentLength(pdfBytes.length);
                        response.setContentType("application/pdf");
                        response.addHeader("Content-Disposition",
                    "attachment;filename=pdffile.pdf");
                        response.getOutputStream().write(pdfBytes);
                        response.getOutputStream().flush();
                    }
                    catch (TransformerException e)
                    {
                        throw e;
                    }
                }
                catch (FOPException e)
                {
                    throw e;
                }
            }
            catch (TransformerConfigurationException e)
            {
                throw e;
            }
            catch (TransformerFactoryConfigurationError e)
            {
                throw e;
            }
        }
    }
}
